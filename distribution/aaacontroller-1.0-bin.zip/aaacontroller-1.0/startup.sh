#!/bin/sh
java -classpath "aaacontroller-1.0.jar" org.lz1aq.aaacontroller.App