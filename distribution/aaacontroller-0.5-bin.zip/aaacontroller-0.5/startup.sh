#!/bin/sh
java -classpath "aaacontroller-0.5.jar" org.lz1aq.aaacontroller.App