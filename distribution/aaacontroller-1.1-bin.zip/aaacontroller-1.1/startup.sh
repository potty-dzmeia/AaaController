#!/bin/sh
java -classpath "aaacontroller-1.1.jar" org.lz1aq.aaacontroller.App